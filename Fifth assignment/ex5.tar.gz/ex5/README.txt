Dolev Ben-Aharon 203723036
Adir Abuhazera 208903765

For compile and run just execute the script attached here
./compileAndRun.sh