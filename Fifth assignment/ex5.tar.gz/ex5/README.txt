Dolev Ben-Aharon 203723036
Adir Abuhazera 208903765
Reut shukron    208162933

For compile and run just execute the script attached here
./compileAndRun.sh